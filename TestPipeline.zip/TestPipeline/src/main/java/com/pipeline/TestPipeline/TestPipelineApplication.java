package com.pipeline.TestPipeline;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestPipelineApplication {

	public static void main(String[] args) {
		SpringApplication.run(TestPipelineApplication.class, args);
	}

}
